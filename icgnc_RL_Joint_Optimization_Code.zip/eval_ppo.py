# eval_ppo.py
import os
import csv
import argparse
import numpy as np

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

from envs.nrs_env import NRSJammingEnv


def make_env(seed: int, start_pos_id=None):
    def _init():
        env = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)
        env = Monitor(env)
        return env
    return _init


def guess_vecnorm_path(model_path: str) -> str:
    """
    model_path: runs/.../best_model/best_model.zip  or runs/.../ppo_nrs_final.zip
    We want runs/.../vecnormalize.pkl
    """
    d = os.path.dirname(model_path)  # .../best_model
    parent = os.path.dirname(d)      # runs/.../
    cand = os.path.join(parent, "vecnormalize.pkl")
    return cand


def run_eval(model_path: str,
             vecnorm_path: str = None,
             episodes: int = 100,
             deterministic: bool = True,
             seed: int = 0,
             start_pos_id=None,
             save_csv: str = None):
    assert os.path.exists(model_path), f"Model not found: {model_path}"

    # load model
    model = PPO.load(model_path)

    # build vec env
    venv = DummyVecEnv([make_env(seed=seed + 123, start_pos_id=start_pos_id)])

    # load VecNormalize stats if provided / guessed
    if vecnorm_path is None:
        vecnorm_path = guess_vecnorm_path(model_path)

    if os.path.exists(vecnorm_path):
        venv = VecNormalize.load(vecnorm_path, venv)
        venv.training = False
        venv.norm_reward = False
        print(f"[OK] Loaded VecNormalize stats: {vecnorm_path}")
    else:
        print(f"[WARN] VecNormalize stats not found: {vecnorm_path}")
        print("       Evaluating WITHOUT normalization (may be inaccurate if training used VecNormalize).")

    rows = []
    success_list, alive_list, timeout_list = [], [], []
    ep_rets, ep_lens = [], []
    j2s1_list, j2s2_list, pj1_list = [], [], []
    m2t_list, margin_list = [], []

    for ep in range(episodes):
        obs = venv.reset()
        done = False
        ep_ret = 0.0
        ep_len = 0
        last_info = {}

        while not done:
            action, _ = model.predict(obs, deterministic=deterministic)
            obs, reward, done, infos = venv.step(action)

            ep_ret += float(reward[0])
            ep_len += 1
            last_info = infos[0]

        success = bool(last_info.get("success", False))
        alive = bool(last_info.get("alive", False))
        timeout = bool(last_info.get("timeout", False))
        j2s1 = float(last_info.get("j2s_s1_db", np.nan))
        j2s2 = float(last_info.get("j2s_s2_db", np.nan))
        pj1 = float(last_info.get("pj_s1", np.nan))
        m2t = float(last_info.get("M2T", np.nan))
        margin = float(last_info.get("margin_db", np.nan))

        print(f"[ep {ep:03d}] len={ep_len:4d} ret={ep_ret:8.2f} "
              f"success={int(success)} alive={int(alive)} timeout={int(timeout)} "
              f"M2T_end={m2t:7.2f} margin_end={margin:7.2f} "
              f"J2S1={j2s1:6.2f} J2S2={j2s2:6.2f} pj1={pj1:5.3f}")

        success_list.append(success)
        alive_list.append(alive)
        timeout_list.append(timeout)
        ep_rets.append(ep_ret)
        ep_lens.append(ep_len)
        j2s1_list.append(j2s1)
        j2s2_list.append(j2s2)
        pj1_list.append(pj1)
        m2t_list.append(m2t)
        margin_list.append(margin)

        rows.append({
            "episode": ep,
            "return": ep_ret,
            "length": ep_len,
            "success": int(success),
            "alive_end": int(alive),
            "timeout": int(timeout),
            "j2s_s1_db_end": j2s1,
            "j2s_s2_db_end": j2s2,
            "pj_s1_end": pj1,
            "M2T_end": m2t,
            "margin_db_end": margin,
        })

    def mean(x): return float(np.nanmean(np.asarray(x, dtype=np.float64)))
    def std(x):  return float(np.nanstd(np.asarray(x, dtype=np.float64)))

    print("=" * 60)
    print(f"Model: {model_path}")
    print(f"Episodes: {episodes}, deterministic={deterministic}")
    print("-" * 60)
    print(f"Success rate: {100.0 * mean(success_list):.2f}%")
    print(f"Alive@end rate: {100.0 * mean(alive_list):.2f}%")
    print(f"Timeout rate: {100.0 * mean(timeout_list):.2f}%")
    print(f"Return: mean {mean(ep_rets):.2f}, std {std(ep_rets):.2f}")
    print(f"Length: mean {mean(ep_lens):.2f}, std {std(ep_lens):.2f}")
    print(f"End M2T: mean {mean(m2t_list):.2f}, std {std(m2t_list):.2f}")
    print(f"End margin(dB): mean {mean(margin_list):.2f}, std {std(margin_list):.2f}")
    print(f"End J2S S1(dB): mean {mean(j2s1_list):.2f}, std {std(j2s1_list):.2f}")
    print(f"End J2S S2(dB): mean {mean(j2s2_list):.2f}, std {std(j2s2_list):.2f}")
    print(f"End pj_s1: mean {mean(pj1_list):.3f}, std {std(pj1_list):.3f}")
    print("=" * 60)

    if save_csv is not None:
        os.makedirs(os.path.dirname(save_csv) or ".", exist_ok=True)
        with open(save_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved per-episode results to: {save_csv}")

    venv.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default="runs/nrs_ppo_20260303_203234/best_model/best_model.zip")
    ap.add_argument("--vecnorm", type=str, default=None, help="path to vecnormalize.pkl (optional)")
    ap.add_argument("--episodes", type=int, default=50)
    ap.add_argument("--deterministic", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--start_pos_id", type=int, default=0)
    ap.add_argument("--csv", type=str, default=None)
    args = ap.parse_args()

    start_pos_id = None if args.start_pos_id < 0 else int(args.start_pos_id)

    run_eval(
        model_path=args.model,
        vecnorm_path=args.vecnorm,
        episodes=args.episodes,
        deterministic=bool(args.deterministic),
        seed=args.seed,
        start_pos_id=start_pos_id,
        save_csv=args.csv
    )


if __name__ == "__main__":
    main()