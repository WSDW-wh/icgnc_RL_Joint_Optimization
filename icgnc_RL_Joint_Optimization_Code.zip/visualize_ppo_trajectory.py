# visualize_ppo_trajectory.py
import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

from envs.nrs_env import NRSJammingEnv


def make_env(seed: int, start_pos_id=None):
    def _init():
        env = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)
        env = Monitor(env)
        return env

    return _init


def guess_vecnorm_path(model_path: str) -> str:
    d = os.path.dirname(model_path)
    parent = os.path.dirname(d)
    cand = os.path.join(parent, "vecnormalize.pkl")
    return cand


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default="runs/nrs_ppo_20260303_203234/best_model/best_model.zip")
    ap.add_argument("--vecnorm", type=str, default=None)
    ap.add_argument("--start_pos_id", type=int, default=0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--save_path", type=str, default="ppo_trajectory_plot.png")
    args = ap.parse_args()

    assert os.path.exists(args.model), f"Model not found: {args.model}"

    start_pos_id = None if args.start_pos_id < 0 else int(args.start_pos_id)
    venv = DummyVecEnv([make_env(seed=args.seed, start_pos_id=start_pos_id)])

    vecnorm_path = args.vecnorm if args.vecnorm else guess_vecnorm_path(args.model)
    if os.path.exists(vecnorm_path):
        venv = VecNormalize.load(vecnorm_path, venv)
        venv.training = False
        venv.norm_reward = False
        print(f"[OK] Loaded VecNormalize stats: {vecnorm_path}")
    else:
        print(f"[WARN] VecNormalize stats not found. Evaluated without normalization.")

    model = PPO.load(args.model)

    j_xs, j_ys = [], []
    m_xs, m_ys = [], []

    obs = venv.reset()
    base_env = venv.envs[0].env

    # 记录初始位置
    j_xs.append(base_env.J_pos[0])
    j_ys.append(base_env.J_pos[1])
    m_xs.append(base_env.M_pos[0])
    m_ys.append(base_env.M_pos[1])

    done = False
    ep_ret = 0.0
    t = 0
    last_info = {}

    print("开始模拟运行 PPO 模型...")
    while not done:
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, done_arr, infos = venv.step(action)

        # ✅ 关键修复 1：第一时间把这一步的 reward 和 info 存下来！
        # 这样即使这一步是最后一步，我们也能拿到 success=True 的状态
        ep_ret += float(reward[0])
        t += 1
        last_info = infos[0]

        # ✅ 关键修复 2：拿到 info 后再判断是否 break
        # 如果 done_arr 为 True，说明底层已经 reset 到了下一局起点
        if done_arr[0]:
            break

        # 如果还没结束，就把当前的真实物理坐标记录到画图列表里
        j_xs.append(base_env.J_pos[0])
        j_ys.append(base_env.J_pos[1])
        m_xs.append(base_env.M_pos[0])
        m_ys.append(base_env.M_pos[1])

    print("=" * 40)
    print(f"运行结束！总步数: {t}")
    # 这里的 last_info 现在绝对包含 100% 准确的最终状态了
    print(
        f"最终状态 - 成功: {last_info.get('success')}, 存活: {last_info.get('alive')}, 距目标距离: {last_info.get('M2T'):.2f}m")
    print("=" * 40)

    # ================= 绘图部分 =================
    print("正在生成轨迹图...")
    fig, ax = plt.subplots(figsize=(10, 6.5))
    ax.set_xlim(0, base_env.width)
    ax.set_ylim(0, base_env.height)

    # 1. 绘制雷达
    for i, radar in enumerate(base_env.radars):
        ax.plot(radar["pos"][0], radar["pos"][1], '^', color='darkred', markersize=10, label='Radar' if i == 0 else "")

    # 2. 绘制目标点 (Target)
    tx, ty = base_env.target
    ax.plot(tx, ty, '*', color='gold', markeredgecolor='black', markersize=15, label='Target')

    # 3. 绘制范围圈
    circle_fire = Circle((tx, ty), base_env.fire_dis, color='orange', fill=False, linestyle='--', linewidth=1.5,
                         label=f'Fire Range ({base_env.fire_dis}m)')
    circle_obs = Circle((tx, ty), base_env.observe_dis, color='gray', fill=False, linestyle=':', linewidth=1.5,
                        label=f'Jammer Limit ({base_env.observe_dis}m)')
    ax.add_patch(circle_fire)
    ax.add_patch(circle_obs)

    # 4. 绘制轨迹
    ax.plot(j_xs, j_ys, '-', color='dodgerblue', alpha=0.8, linewidth=2, label='Jammer Path')
    ax.plot(m_xs, m_ys, '-', color='limegreen', alpha=0.8, linewidth=2, label='Fighter Path')

    # 起点
    ax.plot(j_xs[0], j_ys[0], 'o', color='blue', markersize=6, label='Jammer Start')
    ax.plot(m_xs[0], m_ys[0], 'o', color='darkgreen', markersize=6, label='Fighter Start')

    # 终点
    ax.plot(j_xs[-1], j_ys[-1], 'X', color='blue', markersize=8)
    ax.plot(m_xs[-1], m_ys[-1], 'X', color='darkgreen', markersize=8)

    ax.set_title(f"PPO Centralized Agent Trajectory (Steps: {t})", fontsize=14)
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()

    plt.savefig(args.save_path, dpi=300)
    print(f"图片已保存至: {args.save_path}")
    plt.show()


if __name__ == "__main__":
    main()