# envs/nrs_mappo_env.py
import numpy as np
from gymnasium import spaces

try:
    from ray.rllib.env.multi_agent_env import MultiAgentEnv
except Exception as e:
    raise ImportError('RLlib not found. Install with: pip install -U "ray[rllib]"') from e

from envs.nrs_env import NRSJammingEnv


def _norm_db(x_db: float, lo_db: float = -150.0, hi_db: float = 0.0) -> float:
    # map [lo, hi] -> [-1, 1]
    x = float(np.clip(x_db, lo_db, hi_db))
    return 2.0 * (x - lo_db) / (hi_db - lo_db) - 1.0


def _norm_pos(x: float, hi: float) -> float:
    # map [0, hi] -> [-1, 1]
    return 2.0 * float(np.clip(x, 0.0, hi)) / hi - 1.0


class NRSJammingMAPPOEnv(MultiAgentEnv):
    """
    True MAPPO-style env (CTDE):
    - Actor gets local obs:  jammer_obs or fighter_obs
    - Critic gets global state: (base obs + target rel) normalized
    Each agent observation is a Dict:
        {"obs": local_obs, "state": global_state}
    """

    def __init__(self, config=None):
        super().__init__()
        config = config or {}

        seed = config.get("seed", None)
        start_pos_id = config.get("start_pos_id", 0)  # 0/1/2 or None
        self.include_teammate_rel = bool(config.get("include_teammate_rel", True))

        self.base = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)

        self.agents = ["jammer", "fighter"]
        self._agent_ids = set(self.agents)

        # Action spaces (split from base action [dxJ, dyJ, dxM, dyM, alpha])
        self._action_space_dict = {
            "jammer": spaces.Box(low=-1.0, high=1.0, shape=(3,), dtype=np.float32),   # dxJ, dyJ, alpha
            "fighter": spaces.Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32),  # dxM, dyM
        }

        # ---- Local obs dims ----
        # Jammer obs: [eta_J1, eta_J2, xJ, yJ] + (xM-xJ,yM-yJ) + (xT-xJ,yT-yJ)
        jammer_dim = 4 + (2 if self.include_teammate_rel else 0) + 2
        # Fighter obs: [eta_M1, eta_M2, xM, yM, (xT-xM,yT-yM)] + (xJ-xM,yJ-yM)
        fighter_dim = 2 + 2 + 2 + (2 if self.include_teammate_rel else 0)

        # ---- Global state dim ----
        # base obs 8D + target rel to fighter (2D)
        state_dim = 10

        self._obs_space_dict = {
            "jammer": spaces.Dict(
                {
                    "obs": spaces.Box(low=-1.0, high=1.0, shape=(jammer_dim,), dtype=np.float32),
                    "state": spaces.Box(low=-1.0, high=1.0, shape=(state_dim,), dtype=np.float32),
                }
            ),
            "fighter": spaces.Dict(
                {
                    "obs": spaces.Box(low=-1.0, high=1.0, shape=(fighter_dim,), dtype=np.float32),
                    "state": spaces.Box(low=-1.0, high=1.0, shape=(state_dim,), dtype=np.float32),
                }
            ),
        }

    def observation_space(self, agent_id):
        return self._obs_space_dict[agent_id]

    def action_space(self, agent_id):
        return self._action_space_dict[agent_id]

    def _get_global_state(self) -> np.ndarray:
        # base obs: [eta_J1, eta_J2, eta_M1, eta_M2, xJ, yJ, xM, yM]
        o = self.base._get_obs()
        eta_J1, eta_J2, eta_M1, eta_M2 = float(o[0]), float(o[1]), float(o[2]), float(o[3])
        xJ, yJ, xM, yM = float(o[4]), float(o[5]), float(o[6]), float(o[7])

        # target relative to fighter (guaranteed in [-1,1])
        tx, ty = float(self.base.target[0]), float(self.base.target[1])
        rel_TM = [(tx - xM) / self.base.width, (ty - yM) / self.base.height]

        s = np.array(
            [
                _norm_db(eta_J1),
                _norm_db(eta_J2),
                _norm_db(eta_M1),
                _norm_db(eta_M2),
                _norm_pos(xJ, self.base.width),
                _norm_pos(yJ, self.base.height),
                _norm_pos(xM, self.base.width),
                _norm_pos(yM, self.base.height),
                float(np.clip(rel_TM[0], -1.0, 1.0)),
                float(np.clip(rel_TM[1], -1.0, 1.0)),
            ],
            dtype=np.float32,
        )
        return s

    def _get_local_obs(self) -> dict:
        o = self.base._get_obs()
        eta_J1, eta_J2, eta_M1, eta_M2 = float(o[0]), float(o[1]), float(o[2]), float(o[3])
        xJ, yJ, xM, yM = float(o[4]), float(o[5]), float(o[6]), float(o[7])

        # normalized positions in [-1,1]
        nxJ, nyJ = _norm_pos(xJ, self.base.width), _norm_pos(yJ, self.base.height)
        nxM, nyM = _norm_pos(xM, self.base.width), _norm_pos(yM, self.base.height)

        # relative terms normalized by map size -> guaranteed in [-1,1]
        rel_MJ = [(xM - xJ) / self.base.width, (yM - yJ) / self.base.height]  # M relative to J
        rel_JM = [(xJ - xM) / self.base.width, (yJ - yM) / self.base.height]  # J relative to M

        tx, ty = float(self.base.target[0]), float(self.base.target[1])
        rel_TM = [(tx - xM) / self.base.width, (ty - yM) / self.base.height]  # target relative to M
        rel_TJ = [(tx - xJ) / self.base.width, (ty - yJ) / self.base.height]  # target relative to J

        # Jammer obs: [eta_J1, eta_J2, xJ, yJ, (xM-xJ,yM-yJ optional), (xT-xJ,yT-yJ)]
        jam = [_norm_db(eta_J1), _norm_db(eta_J2), nxJ, nyJ]
        if self.include_teammate_rel:
            jam += [float(np.clip(rel_MJ[0], -1.0, 1.0)), float(np.clip(rel_MJ[1], -1.0, 1.0))]
        jam += [float(np.clip(rel_TJ[0], -1.0, 1.0)), float(np.clip(rel_TJ[1], -1.0, 1.0))]

        # Fighter obs: [eta_M1, eta_M2, xM, yM, (xT-xM,yT-yM), (xJ-xM,yJ-yM optional)]
        fig = [
            _norm_db(eta_M1),
            _norm_db(eta_M2),
            nxM,
            nyM,
            float(np.clip(rel_TM[0], -1.0, 1.0)),
            float(np.clip(rel_TM[1], -1.0, 1.0)),
        ]
        if self.include_teammate_rel:
            fig += [float(np.clip(rel_JM[0], -1.0, 1.0)), float(np.clip(rel_JM[1], -1.0, 1.0))]

        return {"jammer": np.asarray(jam, dtype=np.float32), "fighter": np.asarray(fig, dtype=np.float32)}

    def reset(self, *, seed=None, options=None):
        self.base.reset(seed=seed, options=options)
        state = self._get_global_state()
        local = self._get_local_obs()
        obs = {aid: {"obs": local[aid], "state": state} for aid in self.agents}
        infos = {aid: {} for aid in self.agents}
        return obs, infos

    def step(self, action_dict):
        # build base action: [dxJ, dyJ, dxM, dyM, alpha]
        aj = np.asarray(action_dict.get("jammer", np.zeros(3, dtype=np.float32)), dtype=np.float32).reshape(3)
        am = np.asarray(action_dict.get("fighter", np.zeros(2, dtype=np.float32)), dtype=np.float32).reshape(2)

        base_action = np.zeros(5, dtype=np.float32)
        base_action[0] = aj[0]
        base_action[1] = aj[1]
        base_action[2] = am[0]
        base_action[3] = am[1]
        base_action[4] = aj[2]

        _, reward, terminated, truncated, info = self.base.step(base_action)

        state = self._get_global_state()
        local = self._get_local_obs()
        obs = {aid: {"obs": local[aid], "state": state} for aid in self.agents}

        rewards = {aid: float(reward) for aid in self.agents}

        terminateds = {aid: bool(terminated) for aid in self.agents}
        truncateds = {aid: bool(truncated) for aid in self.agents}
        terminateds["__all__"] = bool(terminated)
        truncateds["__all__"] = bool(truncated)

        infos = {aid: dict(info) for aid in self.agents}
        return obs, rewards, terminateds, truncateds, infos