# envs/nrs_ma_env.py
import numpy as np
import gymnasium as gym
from gymnasium import spaces

try:
    from ray.rllib.env.multi_agent_env import MultiAgentEnv
except Exception as e:
    raise ImportError(
        "RLlib not found. Please install Ray RLlib:\n"
        "  pip install -U 'ray[rllib]'"
    ) from e

from envs.nrs_env import NRSJammingEnv


class NRSJammingMAEnv(MultiAgentEnv):
    """
    Multi-agent wrapper for NRSJammingEnv.
    Agents:
      - "jammer": action [dx_J, dy_J, alpha] in [-1,1]^3
      - "fighter": action [dx_M, dy_M] in [-1,1]^2

    Observation is split (simple local + a tiny bit of shared info).
    You can later remove teammate info to enforce stricter decentralization.
    """

    def __init__(self, config=None):
        config = config or {}
        seed = config.get("seed", None)
        start_pos_id = config.get("start_pos_id", 0)  # 0/1/2 or None for random
        self.include_teammate_rel = bool(config.get("include_teammate_rel", True))

        self.base = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)

        # Agent ids
        self.agents = ["jammer", "fighter"]
        self._agent_ids = set(self.agents)

        # Action spaces
        self._action_space_dict = {
            "jammer": spaces.Box(low=-1.0, high=1.0, shape=(3,), dtype=np.float32),
            "fighter": spaces.Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32),
        }

        # Observation spaces
        # jammer obs: [eta_J1, eta_J2, x_J, y_J, (x_M-x_J, y_M-y_J optional)]
        jammer_dim = 4 + (2 if self.include_teammate_rel else 0)
        # fighter obs: [eta_M1, eta_M2, x_M, y_M, (x_T-x_M, y_T-y_M), (x_J-x_M, y_J-y_M optional)]
        fighter_dim = 2 + 2 + 2 + (2 if self.include_teammate_rel else 0)

        self._obs_space_dict = {
            "jammer": spaces.Box(low=-1e6, high=1e6, shape=(jammer_dim,), dtype=np.float32),
            "fighter": spaces.Box(low=-1e6, high=1e6, shape=(fighter_dim,), dtype=np.float32),
        }

    # RLlib expects these properties
    def observation_space(self, agent_id):
        return self._obs_space_dict[agent_id]

    def action_space(self, agent_id):
        return self._action_space_dict[agent_id]

    def _split_obs(self):
        # Base obs order:
        # [eta_J1, eta_J2, eta_M1, eta_M2, x_J, y_J, x_M, y_M]
        o = self.base._get_obs()
        eta_J1, eta_J2, eta_M1, eta_M2 = float(o[0]), float(o[1]), float(o[2]), float(o[3])
        xJ, yJ, xM, yM = float(o[4]), float(o[5]), float(o[6]), float(o[7])

        # Jammer obs
        jam = [eta_J1, eta_J2, xJ, yJ]
        if self.include_teammate_rel:
            jam += [xM - xJ, yM - yJ]

        # Fighter obs
        tx, ty = float(self.base.target[0]), float(self.base.target[1])
        fig = [eta_M1, eta_M2, xM, yM, tx - xM, ty - yM]
        if self.include_teammate_rel:
            fig += [xJ - xM, yJ - yM]

        obs = {
            "jammer": np.asarray(jam, dtype=np.float32),
            "fighter": np.asarray(fig, dtype=np.float32),
        }
        return obs

    def reset(self, *, seed=None, options=None):
        obs, info = self.base.reset(seed=seed, options=options)
        # RLlib multi-agent reset returns obs dict and infos dict (new API),
        # but it also tolerates returning obs only. We'll return both.
        obs_dict = self._split_obs()
        infos = {aid: {} for aid in self.agents}
        return obs_dict, infos

    def step(self, action_dict):
        # Build the 5D base action = [dx_J, dy_J, dx_M, dy_M, alpha]
        aj = np.asarray(action_dict.get("jammer", np.zeros(3, dtype=np.float32)), dtype=np.float32).reshape(3)
        am = np.asarray(action_dict.get("fighter", np.zeros(2, dtype=np.float32)), dtype=np.float32).reshape(2)

        base_action = np.zeros(5, dtype=np.float32)
        base_action[0] = aj[0]
        base_action[1] = aj[1]
        base_action[4] = aj[2]
        base_action[2] = am[0]
        base_action[3] = am[1]

        obs, reward, terminated, truncated, info = self.base.step(base_action)

        obs_dict = self._split_obs()

        # Shared team reward
        rewards = {aid: float(reward) for aid in self.agents}

        # Per-agent termination flags (same for both; it is a cooperative task)
        terminateds = {aid: bool(terminated) for aid in self.agents}
        truncateds = {aid: bool(truncated) for aid in self.agents}
        terminateds["__all__"] = bool(terminated)
        truncateds["__all__"] = bool(truncated)

        # Provide same info to both agents (you can later split)
        infos = {aid: dict(info) for aid in self.agents}

        return obs_dict, rewards, terminateds, truncateds, infos