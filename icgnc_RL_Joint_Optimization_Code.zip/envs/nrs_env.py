# envs/nrs_env.py
import numpy as np
import gymnasium as gym
from gymnasium import spaces


class NRSJammingEnv(gym.Env):
    """
    NRS penetration toy env (1 Jammer + 1 Fighter + 2 Radars), no rendering.

    Observation (8,):
      [eta_J_S1, eta_J_S2, eta_M_S1, eta_M_S2, x_J, y_J, x_M, y_M]

    Action (5,) in [-1,1]:
      [dx_J, dy_J, dx_M, dy_M, alpha]
      dx/dy are scaled by max_step.
      alpha mapped to Pj_S1 in [0,1] via (alpha+1)/2.
    """

    metadata = {"render_modes": []}

    def __init__(self, start_pos_id=None, seed=None):
        super().__init__()
        self.rng = np.random.default_rng(seed)

        # Map
        self.width, self.height = 1000.0, 650.0
        self.target = np.array([949.0, 544.0], dtype=np.float32)
        self.fire_dis = 280.0
        self.observe_dis = 350.0
        self.t_max = 1000

        # Start points: (J_start, M_start)
        self.start_points = [
            (np.array([70.0, 70.0], dtype=np.float32), np.array([50.0, 20.0], dtype=np.float32)),
            (np.array([140.0, 270.0], dtype=np.float32), np.array([160.0, 280.0], dtype=np.float32)),
            (np.array([245.0, 60.0], dtype=np.float32), np.array([255.0, 70.0], dtype=np.float32)),
        ]
        self.start_pos_id = start_pos_id  # None -> random among 0/1/2, else fixed id

        # Aircraft params
        self.rcs_J = 5.0
        self.rcs_M = 1.0
        self.smin_J = -150.0
        self.smin_M = -140.0

        # Jammer power
        self.jammer_pwr = 1e3  # W
        self.pj_factors = np.array([0.7, 0.3], dtype=np.float32)

        # Radar params (two radars)
        self.radars = [
            {
                "pos": np.array([870.0, 550.0], dtype=np.float32),
                "Pt": 15e6,
                "freq": 5.6e9,
                "G": 40.0,      # dB
                "T": 290.0,
                "tau": 100e-6,
                "Kj": 20.0,     # dB threshold
            },
            {
                "pos": np.array([920.0, 580.0], dtype=np.float32),
                "Pt": 15e6,
                "freq": 5.6e9,
                "G": 40.0,      # dB
                "T": 290.0,
                "tau": 100e-6,
                "Kj": 20.0,     # dB threshold
            },
        ]

        # RL spaces (gymnasium)
        self.observation_space = spaces.Box(low=-1e6, high=1e6, shape=(8,), dtype=np.float32)
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(5,), dtype=np.float32)

        # Action scaling
        self.max_step = 10.0

        # Reward knobs (tuned for "fixed start first" training)
        self.k_progress = 4.0        # weight for (prev_dist - new_dist)
        self.k_dist_abs = 2.0        # small penalty on absolute distance (scaled by /1000)
        self.step_penalty = 0.02    # tiny per-step penalty
        self.k_margin = 0.05       # safety margin shaping weight
        self.margin_scale = 10.0      # dB scale for tanh

        self.r_success = 100000.0
        self.r_death = -1000.0
        self.r_timeout = -1500.0

        # State
        self.J_pos = np.zeros(2, dtype=np.float32)
        self.M_pos = np.zeros(2, dtype=np.float32)
        self.step_cnt = 0
        self.M_alive = True
        self.prev_M2T = 0.0

        self.min_M2T = 2000.0
        # --- 新增：阶段性奖励相关的初始化 ---
        self.checkpoints = [800.0, 600.0, 400.0, 320.0]
        self.reached_checkpoints = [False] * len(self.checkpoints)

    @staticmethod
    def _euclid(a: np.ndarray, b: np.ndarray) -> float:
        d = a - b
        return float(np.sqrt(d[0] * d[0] + d[1] * d[1]))

    def _receive_radar_signal_feature(self, aircraft_pos, rcs, smin_db, radar) -> float:
        """
        Simple observation feature:
          Ap ~ RCS * Pt / (4*pi*R^2)  -> dB
        Use finite floor (avoid -inf).
        """
        R = self._euclid(aircraft_pos, radar["pos"])
        R_m = max(R * 1000.0, 1.0)
        Ap = rcs * radar["Pt"] / (4.0 * np.pi * (R_m ** 2))
        Ap_db = 10.0 * np.log10(max(Ap, 1e-30))
        return float(max(Ap_db, smin_db))

    def _compute_angle_factor(self, radar_pos, jammer_pos, fighter_pos) -> float:
        """
        Angle factor:
        angle at radar between vectors (radar->jammer) and (radar->fighter).
        """
        v1 = jammer_pos - radar_pos
        v2 = fighter_pos - radar_pos
        n1 = float(np.linalg.norm(v1))
        n2 = float(np.linalg.norm(v2))
        if n1 < 1e-9 or n2 < 1e-9:
            return 1.0
        cos_th = float(np.dot(v1, v2) / (n1 * n2))
        cos_th = float(np.clip(cos_th, -1.0, 1.0))
        theta = np.arccos(abs(cos_th)) / np.pi * 13.0
        angle_factor = max(0.1 ** 2.0, (0.1 ** (abs(theta) ** 2)))
        return float(angle_factor)

    def _compute_J2S_db(self, jammer_pos, jammer_power_w, radar, fighter_pos, fighter_rcs) -> float:
        """
        J/S in dB:
          Prs ~ Pt * G^2 * lambda^2 * sigma / ((4pi)^3 * Rf^4)
          Prj ~ Pj * G  * lambda^2 * angle / ((4pi)^2 * Rj^2)
        Return: 10log10(Prj) - 10log10(Prs)
        """
        c = 3.0e8
        lam = c / radar["freq"]
        lam2_db = 10.0 * np.log10(max(lam * lam, 1e-30))

        Rf = max(self._euclid(fighter_pos, radar["pos"]) * 1000.0, 1.0)
        Rj = max(self._euclid(jammer_pos, radar["pos"]) * 1000.0, 1.0)

        p_peak_db = 10.0 * np.log10(max(radar["Pt"], 1e-30))
        sigma_db = 10.0 * np.log10(max(fighter_rcs, 1e-30))
        four_pi_cub_db = 10.0 * np.log10((4.0 * np.pi) ** 3)
        four_pi_sq_db = 10.0 * np.log10((4.0 * np.pi) ** 2)
        Rf4_db = 10.0 * np.log10(max(Rf ** 4, 1e-30))
        Rj2_db = 10.0 * np.log10(max(Rj ** 2, 1e-30))

        Prs_db = p_peak_db + radar["G"] + radar["G"] + lam2_db + sigma_db - four_pi_cub_db - Rf4_db

        angle_factor = self._compute_angle_factor(radar["pos"], jammer_pos, fighter_pos)
        angle_db = 10.0 * np.log10(max(angle_factor, 1e-30))
        Pj_db = 10.0 * np.log10(max(jammer_power_w, 1e-30))
        Prj_db = Pj_db + radar["G"] + angle_db + lam2_db - four_pi_sq_db - Rj2_db

        return float(Prj_db - Prs_db)

    def _get_obs(self) -> np.ndarray:
        eta_J1 = self._receive_radar_signal_feature(self.J_pos, self.rcs_J, self.smin_J, self.radars[0])
        eta_J2 = self._receive_radar_signal_feature(self.J_pos, self.rcs_J, self.smin_J, self.radars[1])
        eta_M1 = self._receive_radar_signal_feature(self.M_pos, self.rcs_M, self.smin_M, self.radars[0])
        eta_M2 = self._receive_radar_signal_feature(self.M_pos, self.rcs_M, self.smin_M, self.radars[1])

        return np.array(
            [eta_J1, eta_J2, eta_M1, eta_M2,
             float(self.J_pos[0]), float(self.J_pos[1]), float(self.M_pos[0]), float(self.M_pos[1])],
            dtype=np.float32
        )

    def _j_allowed(self, next_J_pos: np.ndarray) -> bool:
        # Jammer should stay outside the observe circle around target
        return self._euclid(next_J_pos, self.target) > self.observe_dis

    def _clip_to_map(self, pos: np.ndarray):
        # Keep inside the map (left/top too), with a small margin
        pos[0] = float(np.clip(pos[0], 0.0, self.width))
        pos[1] = float(np.clip(pos[1], 0.0, self.height))

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)

        env_id = int(self.start_pos_id) if self.start_pos_id is not None else int(self.rng.integers(0, 3))
        env_id = int(np.clip(env_id, 0, 2))
        J0, M0 = self.start_points[env_id]

        self.J_pos = J0.copy()
        self.M_pos = M0.copy()

        self.pj_factors = np.array([0.7, 0.3], dtype=np.float32)
        self.step_cnt = 0
        self.M_alive = True
        self.prev_M2T = self._euclid(self.M_pos, self.target)
        self.min_M2T = self.prev_M2T
        obs = self._get_obs()
        info = {}
        self.reached_checkpoints = [False] * len(self.checkpoints)
        return obs, info

    def step(self, action):
        # Clip action
        a = np.asarray(action, dtype=np.float32).reshape(-1)
        a = np.clip(a, -1.0, 1.0)

        # Movement
        dx_J = float(a[0] * self.max_step)
        dy_J = float(a[1] * self.max_step)
        dx_M = float(a[2] * self.max_step)
        dy_M = float(a[3] * self.max_step)

        # Power allocation alpha -> [0,1]
        alpha = float(a[4])
        Pj_S1 = float(np.clip(0.5 * (alpha + 1.0), 0.001, 0.999))
        self.pj_factors = np.array([Pj_S1, 1.0 - Pj_S1], dtype=np.float32)

        # Update Jammer position with observe circle constraint
        next_J = self.J_pos + np.array([dx_J, dy_J], dtype=np.float32)
        if self._j_allowed(next_J):
            self.J_pos = next_J
        else:
            # push away from target to keep constraint
            away = self.J_pos - self.target
            n = float(np.linalg.norm(away))
            if n < 1e-6:
                away = np.array([-1.0, -1.0], dtype=np.float32)
                n = float(np.linalg.norm(away))
            away = away / n
            push = (10.0 + 10.0 * float(self.rng.random()))
            self.J_pos = self.J_pos + away.astype(np.float32) * np.float32(push)

        # Update Fighter
        self.M_pos = self.M_pos + np.array([dx_M, dy_M], dtype=np.float32)

        # Clip to map (both agents)
        self._clip_to_map(self.J_pos)
        self._clip_to_map(self.M_pos)

        # J/S checks
        j2s_1 = self._compute_J2S_db(
            self.J_pos, self.jammer_pwr * float(self.pj_factors[0]),
            self.radars[0], self.M_pos, self.rcs_M
        )
        j2s_2 = self._compute_J2S_db(
            self.J_pos, self.jammer_pwr * float(self.pj_factors[1]),
            self.radars[1], self.M_pos, self.rcs_M
        )

        Kj1 = float(self.radars[0]["Kj"])
        Kj2 = float(self.radars[1]["Kj"])
        self.M_alive = bool((j2s_1 > Kj1) and (j2s_2 > Kj2))

        # ===== Reward shaping (key changes) =====
        # Progress reward: encourage moving closer to target
        # ==========================================================
        # 🎯 纯奖励机制破局 (严酷生存法则)
        # ==========================================================
        M2T = self._euclid(self.M_pos, self.target)
        reward = 0.0

        # 1. 基础进度与拓荒 (重赏勇夫)
        raw_progress = float(self.prev_M2T - M2T)
        progress = float(np.clip(raw_progress, -10.0, 10.0))
        reward += 15.0 * progress  # 提高单步推线奖励
        self.prev_M2T = M2T

        if M2T < self.min_M2T:
            reward += 20.0 * float(self.min_M2T - M2T)  # 破纪录赚大钱
            self.min_M2T = M2T

        # 2. 窄波束护盾“工资”
        margin = float(min(j2s_1 - Kj1, j2s_2 - Kj2))
        if margin >= 0.0:
            # 只要干扰机能保住战斗机的命，每步给高额工资
            reward += 5.0 * min(margin, 5.0)

        # 3. 🔥 核心修改：极其严厉的怠工惩罚
        # 只要游戏没结束，每走一步强制扣除 2.5 分。
        # 如果它们耗满 1000 步，光这项惩罚就会高达 -2500 分！
        reward -= 2.5

        # 4. 终端结算
        success = (M2T <= self.fire_dis) and self.M_alive
        death = (not self.M_alive)
        self.step_cnt += 1
        timeout = (self.step_cnt >= self.t_max)

        if success:
            reward += 100000.0  # 最终大奖
        elif death:
            # 🔥 死亡只扣 1000 分。
            # 算一笔账：与其原地挂机 1000 步被扣 2500 分，不如冲锋试错死掉（只扣 1000 分）！
            reward -= 1000.0

        terminated = bool(success or death)
        truncated = bool(timeout and (not terminated))

        info = {
            "success": success,
            "alive": self.M_alive,
            "timeout": timeout,
            "j2s_s1_db": j2s_1,
            "j2s_s2_db": j2s_2,
            "pj_s1": float(self.pj_factors[0]),
            "M2T": float(M2T),
            "margin_db": float(margin),
        }
        return self._get_obs(), float(reward), terminated, truncated, info