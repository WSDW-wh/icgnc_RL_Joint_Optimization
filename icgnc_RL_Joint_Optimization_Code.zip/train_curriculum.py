# train_curriculum.py
# Curriculum fine-tuning for NRS PPO:
# 1) Load an existing trained model (and VecNormalize stats)
# 2) Decrease fire_dis step-by-step: e.g., 280 -> 260 -> 240 -> 220 -> 200 -> 180
# 3) Continue training at each stage and evaluate success rate
#
# Usage example:
#   python train_curriculum.py --init_model runs/nrs_ppo_20260303_203234/best_model/best_model.zip
#
# Notes:
# - You MUST set env.fire_dis before training each stage (we do it via env.env_method).
# - VecNormalize stats are loaded from the same run folder by default (vecnormalize.pkl).
# - Works on Windows.

import os
import time
import csv
import argparse
from datetime import datetime

import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize


from envs.nrs_env import NRSJammingEnv


def make_env(seed: int, start_pos_id=None):
    def _init():
        env = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)
        env = Monitor(env)
        return env
    return _init


def guess_run_dir_from_model(model_path: str) -> str:
    """
    model_path examples:
      runs/nrs_ppo_xxx/best_model/best_model.zip
      runs/nrs_ppo_xxx/ppo_nrs_final.zip
    return:
      runs/nrs_ppo_xxx
    """
    d = os.path.dirname(model_path)          # .../best_model  OR .../ (if model in root)
    if os.path.basename(d) == "best_model":
        return os.path.dirname(d)
    return d


def set_fire_dis(venv, fire_dis: float):
    # DummyVecEnv has env_method to call underlying env methods/attributes
    # We directly set attribute on the base env (NRSJammingEnv)
    venv.env_method("set_attr", "fire_dis", float(fire_dis))


def evaluate_success(model: PPO, venv, episodes: int = 50, deterministic: bool = True, seed: int = 0):
    """
    Evaluate success/alive/timeout and return a dict of metrics.
    Works with VecNormalize-wrapped VecEnv.
    """
    success_list = []
    alive_list = []
    timeout_list = []
    lens = []
    rets = []
    m2t_end_list = []
    margin_end_list = []

    for ep in range(episodes):
        obs = venv.reset(seed=seed + 1000 + ep)
        done = False
        ep_ret = 0.0
        ep_len = 0
        last_info = {}

        while not done:
            action, _ = model.predict(obs, deterministic=deterministic)
            obs, reward, done, infos = venv.step(action)
            ep_ret += float(reward[0])
            ep_len += 1
            last_info = infos[0]

        success_list.append(int(bool(last_info.get("success", False))))
        alive_list.append(int(bool(last_info.get("alive", False))))
        timeout_list.append(int(bool(last_info.get("timeout", False))))
        lens.append(ep_len)
        rets.append(ep_ret)
        m2t_end_list.append(float(last_info.get("M2T", np.nan)))
        margin_end_list.append(float(last_info.get("margin_db", np.nan)))

    def mean(x): return float(np.nanmean(np.asarray(x, dtype=np.float64)))
    def std(x):  return float(np.nanstd(np.asarray(x, dtype=np.float64)))

    return {
        "success_rate": 100.0 * mean(success_list),
        "alive_rate": 100.0 * mean(alive_list),
        "timeout_rate": 100.0 * mean(timeout_list),
        "ret_mean": mean(rets),
        "ret_std": std(rets),
        "len_mean": mean(lens),
        "len_std": std(lens),
        "m2t_end_mean": mean(m2t_end_list),
        "m2t_end_std": std(m2t_end_list),
        "margin_end_mean": mean(margin_end_list),
        "margin_end_std": std(margin_end_list),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init_model", type=str, required=True, help="path to existing .zip model to continue training")
    ap.add_argument("--vecnorm", type=str, default=None, help="path to vecnormalize.pkl (default: infer from init_model)")
    ap.add_argument("--start_pos_id", type=int, default=0, help="0/1/2 fixed; -1 for random among 3")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", type=str, default="auto")
    ap.add_argument("--stages", type=str, default="280,260,240,220", help="comma-separated fire_dis values")
    ap.add_argument("--timesteps_per_stage", type=int, default=1_000_000)
    ap.add_argument("--eval_episodes", type=int, default=50)
    ap.add_argument("--deterministic_eval", type=int, default=1)
    ap.add_argument("--save_freq", type=int, default=200_000)
    args = ap.parse_args()

    init_model = args.init_model
    assert os.path.exists(init_model), f"init_model not found: {init_model}"

    run_dir = guess_run_dir_from_model(init_model)

    # output dir for curriculum run
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join(run_dir, f"curriculum_{run_id}")
    os.makedirs(out_dir, exist_ok=True)

    start_pos_id = None if args.start_pos_id < 0 else int(args.start_pos_id)
    stages = [float(x.strip()) for x in args.stages.split(",") if x.strip()]

    # build vec envs
    env = DummyVecEnv([make_env(seed=args.seed, start_pos_id=start_pos_id)])
    eval_env = DummyVecEnv([make_env(seed=args.seed + 123, start_pos_id=start_pos_id)])

    # load VecNormalize stats
    vec_path = args.vecnorm
    if vec_path is None:
        vec_path = os.path.join(run_dir, "vecnormalize.pkl")
    if not os.path.exists(vec_path):
        raise FileNotFoundError(f"VecNormalize stats not found: {vec_path}")

    env = VecNormalize.load(vec_path, env)
    eval_env = VecNormalize.load(vec_path, eval_env)
    eval_env.training = False
    eval_env.norm_reward = False

    # load model and attach env
    model = PPO.load(init_model, env=env, device=args.device)

    # prepare CSV log
    csv_path = os.path.join(out_dir, "curriculum_results.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "stage_fire_dis",
                "timesteps_trained",
                "success_rate",
                "alive_rate",
                "timeout_rate",
                "ret_mean",
                "ret_std",
                "len_mean",
                "len_std",
                "m2t_end_mean",
                "m2t_end_std",
                "margin_end_mean",
                "margin_end_std",
                "model_path",
            ],
        )
        writer.writeheader()

    total_trained = 0

    for i, fire_dis in enumerate(stages):
        print("\n" + "=" * 70)
        print(f"[Stage {i+1}/{len(stages)}] fire_dis = {fire_dis}")
        print("=" * 70)

        # set fire_dis in both train and eval envs
        set_fire_dis(env, fire_dis)
        set_fire_dis(eval_env, fire_dis)

        # train in chunks so we can checkpoint
        remaining = int(args.timesteps_per_stage)
        while remaining > 0:
            chunk = min(remaining, int(args.save_freq))
            model.learn(total_timesteps=chunk, reset_num_timesteps=False)
            remaining -= chunk
            total_trained += chunk

            # save checkpoint
            ckpt_path = os.path.join(out_dir, f"ppo_stage{i+1}_fd{int(fire_dis)}_{total_trained}_steps")
            model.save(ckpt_path)
            # save updated VecNormalize stats (important)
            env.save(os.path.join(out_dir, "vecnormalize.pkl"))

            print(f"  saved: {ckpt_path}.zip")

        # evaluate at this stage
        metrics = evaluate_success(
            model=model,
            venv=eval_env,
            episodes=int(args.eval_episodes),
            deterministic=bool(args.deterministic_eval),
            seed=args.seed,
        )

        print(f"  Success rate: {metrics['success_rate']:.2f}%")
        print(f"  Alive@end rate: {metrics['alive_rate']:.2f}%")
        print(f"  Timeout rate: {metrics['timeout_rate']:.2f}%")
        print(f"  Return mean±std: {metrics['ret_mean']:.2f} ± {metrics['ret_std']:.2f}")
        print(f"  Length mean±std: {metrics['len_mean']:.2f} ± {metrics['len_std']:.2f}")
        print(f"  End M2T mean±std: {metrics['m2t_end_mean']:.2f} ± {metrics['m2t_end_std']:.2f}")
        print(f"  End margin(dB) mean±std: {metrics['margin_end_mean']:.2f} ± {metrics['margin_end_std']:.2f}")

        # write CSV
        with open(csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "stage_fire_dis",
                    "timesteps_trained",
                    "success_rate",
                    "alive_rate",
                    "timeout_rate",
                    "ret_mean",
                    "ret_std",
                    "len_mean",
                    "len_std",
                    "m2t_end_mean",
                    "m2t_end_std",
                    "margin_end_mean",
                    "margin_end_std",
                    "model_path",
                ],
            )
            writer.writerow({
                "stage_fire_dis": fire_dis,
                "timesteps_trained": total_trained,
                "success_rate": metrics["success_rate"],
                "alive_rate": metrics["alive_rate"],
                "timeout_rate": metrics["timeout_rate"],
                "ret_mean": metrics["ret_mean"],
                "ret_std": metrics["ret_std"],
                "len_mean": metrics["len_mean"],
                "len_std": metrics["len_std"],
                "m2t_end_mean": metrics["m2t_end_mean"],
                "m2t_end_std": metrics["m2t_end_std"],
                "margin_end_mean": metrics["margin_end_mean"],
                "margin_end_std": metrics["margin_end_std"],
                "model_path": f"ppo_stage{i+1}_fd{int(fire_dis)}_{total_trained}_steps.zip",
            })

    # save final
    final_path = os.path.join(out_dir, "ppo_curriculum_final")
    model.save(final_path)
    env.save(os.path.join(out_dir, "vecnormalize.pkl"))
    print("\nDone.")
    print(f"Final model: {final_path}.zip")
    print(f"Curriculum CSV: {csv_path}")

    env.close()
    eval_env.close()


if __name__ == "__main__":
    main()