# models/mappo_cc_torch_model.py
import torch
import torch.nn as nn

from ray.rllib.models.torch.torch_modelv2 import TorchModelV2
from ray.rllib.models.torch.fcnet import FullyConnectedNetwork


class MAPPOCentralizedCritic(TorchModelV2, nn.Module):
    """
    Input obs is Dict: {"obs": local_obs, "state": global_state}
    - Actor uses local_obs
    - Critic uses global_state
    """

    def __init__(self, obs_space, action_space, num_outputs, model_config, name):
        TorchModelV2.__init__(self, obs_space, action_space, num_outputs, model_config, name)
        nn.Module.__init__(self)

        local_space = obs_space.original_space["obs"]
        state_space = obs_space.original_space["state"]

        # actor network
        self.actor = FullyConnectedNetwork(
            local_space, action_space, num_outputs, model_config, name + "_actor"
        )

        # critic network (outputs 1 value)
        critic_cfg = dict(model_config)
        self.critic = FullyConnectedNetwork(
            state_space, action_space, 1, critic_cfg, name + "_critic"
        )

        self._value_out = None

    def forward(self, input_dict, state, seq_lens):
        local_obs = input_dict["obs"]["obs"]
        logits, _ = self.actor({"obs": local_obs}, state, seq_lens)

        global_state = input_dict["obs"]["state"]
        v, _ = self.critic({"obs": global_state}, state, seq_lens)
        self._value_out = v.squeeze(-1)

        return logits, state

    def value_function(self):
        return self._value_out