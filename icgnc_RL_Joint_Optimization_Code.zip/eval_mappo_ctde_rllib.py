# eval_mappo_ctde_rllib.py
import os
import argparse
import numpy as np

import ray
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.models import ModelCatalog
from ray.tune.registry import register_env

from envs.nrs_mappo_env import NRSJammingMAPPOEnv
from models.mappo_cc_torch_model import MAPPOCentralizedCritic
import time

def register_everything():
    # ✅必须：注册训练时用的 env name（要一模一样）
    register_env("NRS_MAPPO_CTDE", lambda cfg: NRSJammingMAPPOEnv(cfg))
    # ✅必须：注册 custom model（checkpoint 里会引用它）
    ModelCatalog.register_custom_model("mappo_cc", MAPPOCentralizedCritic)


def policy_mapping(agent_id: str) -> str:
    return "jammer_policy" if agent_id == "jammer" else "fighter_policy"


def run_eval(checkpoint_path: str, episodes: int = 50, start_pos_id: int = 0, seed: int = 0, explore: bool = False):
    assert os.path.exists(checkpoint_path), f"Checkpoint not found: {checkpoint_path}"

    ray.init(ignore_reinit_error=True, include_dashboard=False)

    # ✅关键：先注册 env + model，再 load checkpoint
    register_everything()

    algo = Algorithm.from_checkpoint(checkpoint_path)

    # 你也可以直接用 env name（但这里用类更直观）
    env = NRSJammingMAPPOEnv({
        "seed": seed,
        "start_pos_id": (None if start_pos_id < 0 else int(start_pos_id)),
        "include_teammate_rel": True,
    })

    success_list, alive_list, timeout_list = [], [], []
    ep_lens, ep_rets = [], []
    m2t_list, margin_list = [], []


    # 统计量
    total_policy_time = 0.0
    total_step_decision_time = 0.0
    total_policy_calls = 0
    total_env_steps = 0


    for ep in range(episodes):
        obs, infos = env.reset()
        terminated_all, truncated_all = False, False
        ep_ret, t = 0.0, 0
        last_info = None


        while not (terminated_all or truncated_all):
            action_dict = {}
            # 整个 step 的决策时间
            step_decision_t0 = time.perf_counter()
            for aid, ob in obs.items():
                pid = policy_mapping(aid)
                t0 = time.perf_counter()
                act = algo.compute_single_action(observation=ob, policy_id=pid, explore=explore)
                t1 = time.perf_counter()
                if isinstance(act, (tuple, list)):
                    act = act[0]
                action_dict[aid] = act


            step_decision_t1 = time.perf_counter()
            total_step_decision_time += (step_decision_t1 - step_decision_t0)
            total_env_steps += 1
            obs, rewards, terminateds, truncateds, infos = env.step(action_dict)

            r = float(rewards.get("fighter", 0.0))
            ep_ret += r
            t += 1


            terminated_all = bool(terminateds.get("__all__", False))
            truncated_all = bool(truncateds.get("__all__", False))
            last_info = infos.get("fighter", None) or infos.get("jammer", None)

        success = bool(last_info.get("success", False)) if last_info else False
        alive = bool(last_info.get("alive", False)) if last_info else False
        timeout = bool(last_info.get("timeout", False)) if last_info else False
        m2t = float(last_info.get("M2T", np.nan)) if last_info else np.nan
        margin_db = float(last_info.get("margin_db", np.nan)) if last_info else np.nan

        success_list.append(success)
        alive_list.append(alive)
        timeout_list.append(timeout)
        ep_lens.append(t)
        ep_rets.append(ep_ret)
        m2t_list.append(m2t)
        margin_list.append(margin_db)

        print(
            f"[EP {ep:03d}] len={t:4d}, ret={ep_ret:10.3f}, "
            f"success={success}, alive={alive}, timeout={timeout}, "
            f"M2T={m2t:8.3f}, margin_db={margin_db:8.3f}"
        )



    succ = int(np.sum(success_list))
    alive_n = int(np.sum(alive_list))
    timeout_n = int(np.sum(timeout_list))

    print("\n========== EVAL SUMMARY ==========")
    print(f"Episodes: {episodes}")
    print(f"Success:  {succ}/{episodes}  ({succ/episodes*100:.2f}%)")
    print(f"Alive:    {alive_n}/{episodes}  ({alive_n/episodes*100:.2f}%)")
    print(f"Timeout:  {timeout_n}/{episodes}  ({timeout_n/episodes*100:.2f}%)")
    print(f"EpLen:    mean={np.mean(ep_lens):.2f}  std={np.std(ep_lens):.2f}")
    print(f"Return:   mean={np.mean(ep_rets):.2f}  std={np.std(ep_rets):.2f}")
    print(f"M2T:      mean={np.nanmean(m2t_list):.2f}  std={np.nanstd(m2t_list):.2f}")
    print(f"MarginDB: mean={np.nanmean(margin_list):.2f}  std={np.nanstd(margin_list):.2f}")
    print(f"Average time per policy call: {total_policy_time / max(total_policy_calls,1):.6f} s")
    print(f"Average decision time per env step: {total_step_decision_time / max(total_env_steps,1):.6f} s")

    ray.shutdown()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=str, default="runs_rllib/mappo_ctde_nrs_20260308_154405/PPO_NRS_MAPPO_CTDE_966ff_00000_0_2026-03-08_15-44-07/checkpoint_000080")
    ap.add_argument("--episodes", type=int, default=10)
    ap.add_argument("--start_pos_id", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--explore", action="store_true")
    args = ap.parse_args()

    run_eval(args.ckpt, args.episodes, args.start_pos_id, args.seed, args.explore)


if __name__ == "__main__":
    main()