# train_ppo.py
# Windows-friendly PPO training (Stable-Baselines3 + gymnasium)
#
# Install:
#   pip install -U gymnasium stable-baselines3 torch numpy

import os
import time
from datetime import datetime

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
from stable_baselines3.common.evaluation import evaluate_policy

from envs.nrs_env import NRSJammingEnv


def make_env(seed: int, start_pos_id=None):
    def _init():
        env = NRSJammingEnv(start_pos_id=start_pos_id, seed=seed)
        env = Monitor(env)
        return env
    return _init


def main():
    seed = 0
    start_pos_id = 0            # 先固定一个点训练：0/1/2；想三点随机就设 None
    total_timesteps = 10_000_000

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = os.path.join("runs", f"nrs_ppo_{run_id}")
    os.makedirs(out_dir, exist_ok=True)

    # vec envs
    n_envs = 1
    env = DummyVecEnv([make_env(seed=seed, start_pos_id=start_pos_id) for _ in range(n_envs)])
    eval_env = DummyVecEnv([make_env(seed=seed + 123, start_pos_id=start_pos_id)])

    # ===== VecNormalize: normalize observations =====
    env = VecNormalize(env, norm_obs=True, norm_reward=False, clip_obs=10.0)
    eval_env = VecNormalize(eval_env, norm_obs=True, norm_reward=False, clip_obs=10.0)

    # ✅ 关键：让 eval_env 共享训练 env 的归一化统计（否则评估不准）
    eval_env.obs_rms = env.obs_rms

    # Eval env should NOT update running stats
    eval_env.training = False
    eval_env.norm_reward = False

    # callbacks
    ckpt_cb = CheckpointCallback(
        save_freq=50_000,
        save_path=os.path.join(out_dir, "checkpoints"),
        name_prefix="ppo_nrs",
    )

    eval_cb = EvalCallback(
        eval_env,
        best_model_save_path=os.path.join(out_dir, "best_model"),
        log_path=os.path.join(out_dir, "eval_logs"),
        eval_freq=25_000,
        n_eval_episodes=10,
        deterministic=True,
    )

    model = PPO(
        policy="MlpPolicy",
        env=env,
        learning_rate=1e-4,
        n_steps=4096,
        batch_size=256,
        n_epochs=10,
        gamma=0.995,
        gae_lambda=0.95,
        clip_range=0.2,
        ent_coef=0.03,
        vf_coef=0.5,
        max_grad_norm=0.5,
        # ✅ 建议：减小初期探索动作幅度，避免“动不动就死”
        policy_kwargs=dict(net_arch=[64, 64], log_std_init=-1.5),
        verbose=1,
        seed=seed,
        device="auto",
    )

    t0 = time.time()
    model.learn(total_timesteps=total_timesteps, callback=[ckpt_cb, eval_cb])
    print(f"Training time: {time.time() - t0:.1f}s")

    # ===== Save final model + VecNormalize stats =====
    final_path = os.path.join(out_dir, "ppo_nrs_final")
    model.save(final_path)
    print(f"Saved final model: {final_path}.zip")

    vec_path = os.path.join(out_dir, "vecnormalize.pkl")
    env.save(vec_path)
    print(f"Saved VecNormalize stats: {vec_path}")

    # ===== Evaluate (eval_env already uses shared normalization) =====
    mean_r, std_r = evaluate_policy(model, eval_env, n_eval_episodes=20, deterministic=True)
    print(f"Eval mean reward: {mean_r:.2f} +/- {std_r:.2f}")

    env.close()
    eval_env.close()


if __name__ == "__main__":
    main()