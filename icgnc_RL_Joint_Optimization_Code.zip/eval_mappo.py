# eval_rllib_mappo.py
import os
import argparse
import numpy as np

import ray
from ray.rllib.algorithms.algorithm import Algorithm

from envs.nrs_ma_env import NRSJammingMAEnv


def policy_mapping(agent_id: str) -> str:
    return "jammer_policy" if agent_id == "jammer" else "fighter_policy"


def freeze_obs_filters(algo: Algorithm):
    """
    Freeze MeanStdFilter so eval does NOT update running stats.
    This is critical when observation_filter="MeanStdFilter" was used in training.
    """
    try:
        lw = algo.workers.local_worker()
        for pid, pol in lw.policy_map.items():
            f = getattr(pol, "observation_filter", None)
            if f is not None:
                # stop updating running mean/std during evaluation
                f.training = False
        # some versions benefit from syncing filters
        try:
            algo.workers.sync_filters()
        except Exception:
            pass
    except Exception as e:
        print(f"[WARN] freeze_obs_filters failed: {e}")


def run_eval(
    checkpoint_path: str,
    episodes: int = 50,
    start_pos_id: int = 0,
    seed: int = 0,
    explore: bool = False,
):
    assert os.path.exists(checkpoint_path), f"Checkpoint not found: {checkpoint_path}"

    ray.init(ignore_reinit_error=True, include_dashboard=False)

    algo = Algorithm.from_checkpoint(checkpoint_path)

    # ✅关键：冻结 MeanStdFilter（如果训练时开了 observation_filter）
    freeze_obs_filters(algo)

    # 打印确认信息（可删）
    try:
        print("Loaded observation_filter =", algo.config.get("observation_filter"))
        print("Policies =", list(algo.workers.local_worker().policy_map.keys()))
    except Exception:
        pass

    env = NRSJammingMAEnv({
        "seed": seed,
        "start_pos_id": (None if start_pos_id < 0 else int(start_pos_id)),
        "include_teammate_rel": True,
    })

    success_list, alive_list, timeout_list = [], [], []
    ep_lens, ep_rets = [], []
    m2t_list, margin_list = [], []

    for ep in range(episodes):
        obs, infos = env.reset()
        terminated_all, truncated_all = False, False
        ep_ret, t = 0.0, 0
        last_info = None

        while not (terminated_all or truncated_all):
            action_dict = {}

            for aid, ob in obs.items():
                pid = policy_mapping(aid)
                act = algo.compute_single_action(
                    observation=ob,
                    policy_id=pid,
                    explore=explore,
                )
                # some versions return (action, state, info)
                if isinstance(act, (tuple, list)):
                    act = act[0]
                action_dict[aid] = act

            obs, rewards, terminateds, truncateds, infos = env.step(action_dict)

            # team reward（你环境里 fighter/jammer reward 一样）
            r = float(rewards.get("fighter", 0.0))
            ep_ret += r
            t += 1

            terminated_all = bool(terminateds.get("__all__", False))
            truncated_all = bool(truncateds.get("__all__", False))

            # NRSJammingMAEnv.step 会把 base env 的 info 复制给每个 agent
            last_info = infos.get("fighter", None) or infos.get("jammer", None)

        # ---- episode stats ----
        success = bool(last_info.get("success", False)) if last_info else False
        alive = bool(last_info.get("alive", False)) if last_info else False
        timeout = bool(last_info.get("timeout", False)) if last_info else False
        m2t = float(last_info.get("M2T", np.nan)) if last_info else np.nan
        margin_db = float(last_info.get("margin_db", np.nan)) if last_info else np.nan

        success_list.append(success)
        alive_list.append(alive)
        timeout_list.append(timeout)
        ep_lens.append(t)
        ep_rets.append(ep_ret)
        m2t_list.append(m2t)
        margin_list.append(margin_db)

        print(
            f"[EP {ep:03d}] len={t:4d}, ret={ep_ret:10.3f}, "
            f"success={success}, alive={alive}, timeout={timeout}, "
            f"M2T={m2t:8.3f}, margin_db={margin_db:8.3f}"
        )

    # ---- summary ----
    succ = int(np.sum(success_list))
    alive_n = int(np.sum(alive_list))
    timeout_n = int(np.sum(timeout_list))

    print("\n========== EVAL SUMMARY ==========")
    print(f"Episodes: {episodes}")
    print(f"Success:  {succ}/{episodes}  ({succ/episodes*100:.2f}%)")
    print(f"Alive:    {alive_n}/{episodes}  ({alive_n/episodes*100:.2f}%)")
    print(f"Timeout:  {timeout_n}/{episodes}  ({timeout_n/episodes*100:.2f}%)")
    print(f"EpLen:    mean={np.mean(ep_lens):.2f}  std={np.std(ep_lens):.2f}")
    print(f"Return:   mean={np.mean(ep_rets):.2f}  std={np.std(ep_rets):.2f}")
    print(f"M2T:      mean={np.nanmean(m2t_list):.2f}  std={np.nanstd(m2t_list):.2f}")
    print(f"MarginDB: mean={np.nanmean(margin_list):.2f}  std={np.nanstd(margin_list):.2f}")

    ray.shutdown()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=str,
                    default="runs_rllib/mappo_nrs_20260304_230909/PPO_NRSJammingMAEnv_19e22_00000_0_2026-03-04_23-09-11/checkpoint_000245")
    ap.add_argument("--episodes", type=int, default=50)
    ap.add_argument("--start_pos_id", type=int, default=0, help="0/1/2 fixed; -1 random among 3")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--explore", action="store_true", help="enable stochastic sampling")
    args = ap.parse_args()

    run_eval(
        checkpoint_path=args.ckpt,
        episodes=args.episodes,
        start_pos_id=args.start_pos_id,
        seed=args.seed,
        explore=args.explore,
    )


if __name__ == "__main__":
    main()