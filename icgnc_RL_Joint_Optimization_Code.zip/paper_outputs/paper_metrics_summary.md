| Metric | Value |
|---|---:|
| Success Rate | 1.0000 |
| Survival Rate | 1.0000 |
| Timeout Rate | 0.0000 |
| Average Return | 126108.8540 |
| Std Return | 0.0000 |
| Average Final Distance to Target | 275.3222 |
| Average Minimum Margin (dB) | 0.8322 |
| Episodes | 50.0000 |
