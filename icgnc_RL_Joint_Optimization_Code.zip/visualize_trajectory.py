# visualize_trajectory.py
import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle

import ray
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.models import ModelCatalog
from ray.tune.registry import register_env

from envs.nrs_mappo_env import NRSJammingMAPPOEnv
from models.mappo_cc_torch_model import MAPPOCentralizedCritic


def register_everything():
    register_env("NRS_MAPPO_CTDE", lambda cfg: NRSJammingMAPPOEnv(cfg))
    ModelCatalog.register_custom_model("mappo_cc", MAPPOCentralizedCritic)


def policy_mapping(agent_id: str) -> str:
    return "jammer_policy" if agent_id == "jammer" else "fighter_policy"


def main():
    ap = argparse.ArgumentParser()
    # 默认填入你上次测试用的 checkpoint 路径
    ap.add_argument("--ckpt", type=str, default="runs_rllib/mappo_ctde_nrs_20260308_154405/PPO_NRS_MAPPO_CTDE_966ff_00000_0_2026-03-08_15-44-07/checkpoint_000080")
    ap.add_argument("--start_pos_id", type=int, default=0, help="0, 1, or 2 for fixed start, -1 for random")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--explore", action="store_true", help="Enable exploration during eval")
    ap.add_argument("--save_path", type=str, default="trajectory_plot.png")
    args = ap.parse_args()

    assert os.path.exists(args.ckpt), f"Checkpoint not found: {args.ckpt}"

    ray.init(ignore_reinit_error=True, include_dashboard=False)
    register_everything()
    algo = Algorithm.from_checkpoint(args.ckpt)

    env = NRSJammingMAPPOEnv({
        "seed": args.seed,
        "start_pos_id": None if args.start_pos_id < 0 else int(args.start_pos_id),
        "include_teammate_rel": True,
    })

    # 用于记录轨迹的列表
    j_xs, j_ys = [], []
    m_xs, m_ys = [], []

    obs, infos = env.reset()
    terminated_all, truncated_all = False, False

    # 记录初始位置
    j_xs.append(env.base.J_pos[0])
    j_ys.append(env.base.J_pos[1])
    m_xs.append(env.base.M_pos[0])
    m_ys.append(env.base.M_pos[1])

    t = 0
    ep_ret = 0.0

    print("开始模拟运行...")
    while not (terminated_all or truncated_all):
        action_dict = {}
        for aid, ob in obs.items():
            pid = policy_mapping(aid)
            act = algo.compute_single_action(observation=ob, policy_id=pid, explore=args.explore)
            if isinstance(act, (tuple, list)):
                act = act[0]
            action_dict[aid] = act

        obs, rewards, terminateds, truncateds, infos = env.step(action_dict)

        # 记录每一步后的真实物理位置
        j_xs.append(env.base.J_pos[0])
        j_ys.append(env.base.J_pos[1])
        m_xs.append(env.base.M_pos[0])
        m_ys.append(env.base.M_pos[1])

        ep_ret += float(rewards.get("fighter", 0.0))
        t += 1

        terminated_all = bool(terminateds.get("__all__", False))
        truncated_all = bool(truncateds.get("__all__", False))

        last_info = infos.get("fighter", None) or infos.get("jammer", None)

    print(f"运行结束！总步数: {t}, 最终回报: {ep_ret:.2f}")
    if last_info:
        print(
            f"最终状态 - 成功: {last_info.get('success')}, 存活: {last_info.get('alive')}, 距目标距离: {last_info.get('M2T'):.2f}m")

    # ================= 绘图部分 =================
    print("正在生成轨迹图...")
    fig, ax = plt.subplots(figsize=(10, 6.5))
    ax.set_xlim(0, env.base.width)
    ax.set_ylim(0, env.base.height)

    # 1. 绘制雷达
    for i, radar in enumerate(env.base.radars):
        ax.plot(radar["pos"][0], radar["pos"][1], '^', color='darkred', markersize=10, label='Radar' if i == 0 else "")

    # 2. 绘制目标点 (Target)
    tx, ty = env.base.target
    ax.plot(tx, ty, '*', color='gold', markeredgecolor='black', markersize=15, label='Target')

    # 3. 绘制范围圈
    # Fighter开火范围
    circle_fire = Circle((tx, ty), env.base.fire_dis, color='orange', fill=False, linestyle='--', linewidth=1.5,
                         label=f'Fire Range ({env.base.fire_dis}m)')
    # Jammer观测禁区
    circle_obs = Circle((tx, ty), env.base.observe_dis, color='gray', fill=False, linestyle=':', linewidth=1.5,
                        label=f'Jammer Limit ({env.base.observe_dis}m)')
    ax.add_patch(circle_fire)
    ax.add_patch(circle_obs)

    # 4. 绘制轨迹
    # 用浅色画线，深色画起止点
    ax.plot(j_xs, j_ys, '-', color='dodgerblue', alpha=0.6, label='Jammer Path')
    ax.plot(m_xs, m_ys, '-', color='limegreen', alpha=0.6, label='Fighter Path')

    # 起点
    ax.plot(j_xs[0], j_ys[0], 'o', color='blue', markersize=6, label='Jammer Start')
    ax.plot(m_xs[0], m_ys[0], 'o', color='darkgreen', markersize=6, label='Fighter Start')

    # 终点 (用 X 表示)
    ax.plot(j_xs[-1], j_ys[-1], 'X', color='blue', markersize=8)
    ax.plot(m_xs[-1], m_ys[-1], 'X', color='darkgreen', markersize=8)

    # 美化图表
    ax.set_title(f"NRS Jamming Trajectory (Start Pos: {args.start_pos_id})", fontsize=14)
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)  # 图例放右边防遮挡
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()

    # 保存并显示
    plt.savefig(args.save_path, dpi=300)
    print(f"图片已保存至: {args.save_path}")
    plt.show()

    ray.shutdown()


if __name__ == "__main__":
    main()