import os
import sys
import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import ray
from ray.rllib.algorithms.algorithm import Algorithm
from ray.rllib.models import ModelCatalog
from ray.tune.registry import register_env


# =========================
# Utility
# =========================
def ensure_dir(path: str):
    Path(path).mkdir(parents=True, exist_ok=True)


def add_project_root(project_root: str):
    project_root = os.path.abspath(project_root)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)


def setup_rllib_env_and_model(project_root: str):
    """
    Make sure your project root contains:
      envs/nrs_mappo_env.py
      models/mappo_cc_torch_model.py
    """
    add_project_root(project_root)

    from envs.nrs_mappo_env import NRSJammingMAPPOEnv
    from models.mappo_cc_torch_model import MAPPOCentralizedCritic

    register_env("NRS_MAPPO_CTDE", lambda cfg: NRSJammingMAPPOEnv(cfg))
    ModelCatalog.register_custom_model("mappo_cc", MAPPOCentralizedCritic)

    return NRSJammingMAPPOEnv


def safe_float(x, default=np.nan):
    try:
        return float(x)
    except Exception:
        return float(default)


# =========================
# RLlib rollout / eval
# =========================
def build_env(project_root: str, seed=0, start_pos_id=0, include_teammate_rel=True):
    NRSJammingMAPPOEnv = setup_rllib_env_and_model(project_root)
    env = NRSJammingMAPPOEnv(
        {
            "seed": seed,
            "start_pos_id": (None if start_pos_id < 0 else int(start_pos_id)),
            "include_teammate_rel": include_teammate_rel,
        }
    )
    return env


def build_algo(project_root: str, checkpoint: str):
    setup_rllib_env_and_model(project_root)
    ray.init(ignore_reinit_error=True, include_dashboard=False, num_cpus=1)
    algo = Algorithm.from_checkpoint(checkpoint)
    return algo


def close_algo():
    try:
        ray.shutdown()
    except Exception:
        pass


def extract_step_record(env, info, action_jammer, action_fighter, ep, t, ep_ret):
    base = env.base

    pj_s1 = safe_float(info.get("pj_s1", np.nan))
    j2s_s1_db = safe_float(info.get("j2s_s1_db", np.nan))
    j2s_s2_db = safe_float(info.get("j2s_s2_db", np.nan))
    margin_db = safe_float(info.get("margin_db", np.nan))
    m2t = safe_float(info.get("M2T", np.nan))

    row = {
        "episode": ep,
        "t": t,
        "J_x": safe_float(base.J_pos[0]),
        "J_y": safe_float(base.J_pos[1]),
        "F_x": safe_float(base.M_pos[0]),
        "F_y": safe_float(base.M_pos[1]),
        "target_x": safe_float(base.target[0]),
        "target_y": safe_float(base.target[1]),
        "radar1_x": safe_float(base.radars[0]["pos"][0]),
        "radar1_y": safe_float(base.radars[0]["pos"][1]),
        "radar2_x": safe_float(base.radars[1]["pos"][0]),
        "radar2_y": safe_float(base.radars[1]["pos"][1]),
        "fire_dis": safe_float(base.fire_dis),
        "observe_dis": safe_float(base.observe_dis),
        "pj_s1": pj_s1,
        "pj_s2": (1.0 - pj_s1) if np.isfinite(pj_s1) else np.nan,
        "j2s_s1_db": j2s_s1_db,
        "j2s_s2_db": j2s_s2_db,
        "margin_db": margin_db,
        "M2T": m2t,
        "jam_dx": safe_float(action_jammer[0]),
        "jam_dy": safe_float(action_jammer[1]),
        "jam_alpha": safe_float(action_jammer[2]),
        "fig_dx": safe_float(action_fighter[0]),
        "fig_dy": safe_float(action_fighter[1]),
        "ep_return_so_far": safe_float(ep_ret),
    }
    return row


def run_one_episode(algo, env, seed=None, explore=False, episode_index=0):
    obs, infos = env.reset(seed=seed)

    done = False
    truncated = False
    ep_ret = 0.0
    ep_len = 0

    step_rows = []

    while not (done or truncated):
        a_j = algo.compute_single_action(
            obs["jammer"],
            policy_id="jammer_policy",
            explore=explore,
        )
        a_f = algo.compute_single_action(
            obs["fighter"],
            policy_id="fighter_policy",
            explore=explore,
        )

        if isinstance(a_j, tuple):
            a_j = a_j[0]
        if isinstance(a_f, tuple):
            a_f = a_f[0]

        a_j = np.asarray(a_j, dtype=np.float32).reshape(-1)
        a_f = np.asarray(a_f, dtype=np.float32).reshape(-1)

        next_obs, rewards, terminateds, truncateds, infos = env.step(
            {"jammer": a_j, "fighter": a_f}
        )

        r = float(rewards["jammer"])  # shared team reward
        ep_ret += r
        ep_len += 1

        info = infos["jammer"]
        step_rows.append(
            extract_step_record(
                env=env,
                info=info,
                action_jammer=a_j,
                action_fighter=a_f,
                ep=episode_index,
                t=ep_len - 1,
                ep_ret=ep_ret,
            )
        )

        done = bool(terminateds["__all__"])
        truncated = bool(truncateds["__all__"])
        obs = next_obs

    final_info = infos["jammer"]

    episode_summary = {
        "episode": episode_index,
        "success": int(bool(final_info.get("success", False))),
        "alive": int(bool(final_info.get("alive", False))),
        "timeout": int(bool(final_info.get("timeout", False))),
        "return": float(ep_ret),
        "length": int(ep_len),
        "final_M2T": safe_float(final_info.get("M2T", np.nan)),
        "min_margin_db": safe_float(final_info.get("margin_db", np.nan)),
        "final_j2s_s1_db": safe_float(final_info.get("j2s_s1_db", np.nan)),
        "final_j2s_s2_db": safe_float(final_info.get("j2s_s2_db", np.nan)),
        "final_pj_s1": safe_float(final_info.get("pj_s1", np.nan)),
    }

    step_df = pd.DataFrame(step_rows)
    return episode_summary, step_df


def evaluate_episodes(
    project_root: str,
    checkpoint: str,
    episodes: int,
    start_pos_id: int,
    seed: int,
    explore: bool = False,
):
    algo = build_algo(project_root, checkpoint)
    env = build_env(project_root, seed=seed, start_pos_id=start_pos_id)

    episode_summaries = []
    episode_dfs = []

    for ep in range(episodes):
        ep_seed = None if seed is None else int(seed + ep)
        summary, step_df = run_one_episode(
            algo=algo,
            env=env,
            seed=ep_seed,
            explore=explore,
            episode_index=ep,
        )
        episode_summaries.append(summary)
        episode_dfs.append(step_df)

    close_algo()

    ep_df = pd.DataFrame(episode_summaries)
    all_steps_df = pd.concat(episode_dfs, ignore_index=True) if episode_dfs else pd.DataFrame()
    return ep_df, all_steps_df


# =========================
# Summary / table
# =========================
def summarize_metrics(ep_df: pd.DataFrame):
    summary = {
        "Success Rate": ep_df["success"].mean() if "success" in ep_df else np.nan,
        "Survival Rate": ep_df["alive"].mean() if "alive" in ep_df else np.nan,
        "Timeout Rate": ep_df["timeout"].mean() if "timeout" in ep_df else np.nan,
        "Average Return": ep_df["return"].mean() if "return" in ep_df else np.nan,
        "Std Return": ep_df["return"].std(ddof=1) if "return" in ep_df and len(ep_df) > 1 else 0.0,
        "Average Final Distance to Target": ep_df["final_M2T"].mean() if "final_M2T" in ep_df else np.nan,
        "Average Minimum Margin (dB)": ep_df["min_margin_db"].mean() if "min_margin_db" in ep_df else np.nan,
        "Episodes": len(ep_df),
    }
    return pd.DataFrame({"Metric": list(summary.keys()), "Value": list(summary.values())})


def save_summary_table(summary_df: pd.DataFrame, out_dir: str):
    ensure_dir(out_dir)

    csv_path = os.path.join(out_dir, "paper_metrics_summary.csv")
    md_path = os.path.join(out_dir, "paper_metrics_summary.md")
    tex_path = os.path.join(out_dir, "paper_metrics_table.tex")

    summary_df.to_csv(csv_path, index=False)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("| Metric | Value |\n")
        f.write("|---|---:|\n")
        for _, row in summary_df.iterrows():
            val = row["Value"]
            if isinstance(val, (int, np.integer)):
                s = f"{int(val)}"
            elif isinstance(val, (float, np.floating)):
                s = f"{float(val):.4f}"
            else:
                s = str(val)
            f.write(f"| {row['Metric']} | {s} |\n")

    with open(tex_path, "w", encoding="utf-8") as f:
        f.write("\\begin{table}[t]\n")
        f.write("\\caption{Performance of the proposed method over multiple test episodes.}\n")
        f.write("\\label{tab:perf_metrics}\n")
        f.write("\\centering\n")
        f.write("\\begin{tabular}{lc}\n")
        f.write("\\hline\n")
        f.write("Metric & Value \\\\\n")
        f.write("\\hline\n")
        for _, row in summary_df.iterrows():
            val = row["Value"]
            if isinstance(val, (int, np.integer)):
                s = f"{int(val)}"
            elif isinstance(val, (float, np.floating)):
                s = f"{float(val):.4f}"
            else:
                s = str(val)
            metric_name = str(row["Metric"]).replace("&", "\\&")
            f.write(f"{metric_name} & {s} \\\\\n")
        f.write("\\hline\n")
        f.write("\\end{tabular}\n")
        f.write("\\end{table}\n")

    return csv_path, md_path, tex_path


# =========================
# Plotting
# =========================
def plot_training_curve(progress_csv: str, out_dir: str):
    ensure_dir(out_dir)
    df = pd.read_csv(progress_csv)

    # RLlib常见列名兼容
    candidates = [
        "episode_reward_mean",
        "env_runners/episode_return_mean",
        "evaluation/episode_reward_mean",
    ]
    reward_col = None
    for c in candidates:
        if c in df.columns:
            reward_col = c
            break
    if reward_col is None:
        raise ValueError(f"Cannot find reward column in progress.csv. Available cols: {list(df.columns)[:20]}")

    x_col = "timesteps_total" if "timesteps_total" in df.columns else df.columns[0]

    plt.figure(figsize=(7.0, 4.5))
    plt.plot(df[x_col], df[reward_col], linewidth=1.8)
    plt.xlabel("Timesteps")
    plt.ylabel("Episode Return Mean")
    plt.title("Training Curve")
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()

    png_path = os.path.join(out_dir, "training_curve.png")
    pdf_path = os.path.join(out_dir, "training_curve.pdf")
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(pdf_path, bbox_inches="tight")
    plt.close()

    return png_path, pdf_path


def choose_representative_episode(ep_df: pd.DataFrame):
    # 优先选成功样本中 final_M2T 最小的；否则选 final_M2T 最小的
    if "success" in ep_df and ep_df["success"].sum() > 0:
        sub = ep_df[ep_df["success"] == 1].copy()
        idx = sub["final_M2T"].idxmin()
    else:
        idx = ep_df["final_M2T"].idxmin()
    return int(ep_df.loc[idx, "episode"])


def plot_trajectory(step_df: pd.DataFrame, out_dir: str):
    ensure_dir(out_dir)

    if len(step_df) == 0:
        raise ValueError("Empty step_df for trajectory plot.")

    first = step_df.iloc[0]

    plt.figure(figsize=(8.0, 5.5))

    plt.plot(step_df["J_x"], step_df["J_y"], linewidth=2.0, label="Support UAV")
    plt.plot(step_df["F_x"], step_df["F_y"], linewidth=2.0, label="Mission UAV")

    plt.scatter([first["J_x"]], [first["J_y"]], marker="o", s=50, label="Support UAV Start")
    plt.scatter([first["F_x"]], [first["F_y"]], marker="s", s=50, label="Mission UAV Start")

    plt.scatter([first["target_x"]], [first["target_y"]], marker="*", s=140, label="Target")
    plt.scatter([first["radar1_x"]], [first["radar1_y"]], marker="^", s=80, label="Radar 1")
    plt.scatter([first["radar2_x"]], [first["radar2_y"]], marker="^", s=80, label="Radar 2")

    # firing circle
    fire_circle = plt.Circle(
        (first["target_x"], first["target_y"]),
        first["fire_dis"],
        fill=False,
        linestyle="--",
        linewidth=1.5,
    )
    plt.gca().add_patch(fire_circle)

    # jammer observe/keep-out circle
    observe_circle = plt.Circle(
        (first["target_x"], first["target_y"]),
        first["observe_dis"],
        fill=False,
        linestyle=":",
        linewidth=1.5,
    )
    plt.gca().add_patch(observe_circle)

    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("Representative Cooperative Trajectory")
    plt.axis("equal")
    plt.xlim(0, 1000)
    plt.ylim(0, 650)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend(fontsize=9, loc="best")
    plt.tight_layout()

    png_path = os.path.join(out_dir, "trajectory_result.png")
    pdf_path = os.path.join(out_dir, "trajectory_result.pdf")
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(pdf_path, bbox_inches="tight")
    plt.close()

    return png_path, pdf_path


def plot_allocation(step_df: pd.DataFrame, out_dir: str):
    ensure_dir(out_dir)

    if len(step_df) == 0:
        raise ValueError("Empty step_df for allocation plot.")

    t = step_df["t"].values

    fig = plt.figure(figsize=(8.0, 6.5))

    ax1 = plt.subplot(3, 1, 1)
    ax1.plot(t, step_df["pj_s1"], linewidth=1.8, label="Power Ratio to Radar 1")
    ax1.plot(t, step_df["pj_s2"], linewidth=1.8, label="Power Ratio to Radar 2")
    ax1.set_ylabel("Power Ratio")
    ax1.set_title("Dynamic Resource Allocation and Performance Variation")
    ax1.grid(True, linestyle="--", alpha=0.4)
    ax1.legend(fontsize=8, loc="best")

    ax2 = plt.subplot(3, 1, 2)
    ax2.plot(t, step_df["j2s_s1_db"], linewidth=1.8, label="Power Ratio of Radar 1 (dB)")
    ax2.plot(t, step_df["j2s_s2_db"], linewidth=1.8, label="Power Ratio of Radar 2 (dB)")
    ax2.set_ylabel("Power Ratio (dB)")
    ax2.grid(True, linestyle="--", alpha=0.4)
    ax2.legend(fontsize=8, loc="best")

    ax3 = plt.subplot(3, 1, 3)
    ax3.plot(t, step_df["margin_db"], linewidth=1.8, label="Minimum Margin (dB)")
    ax3.axhline(0.0, linestyle="--", linewidth=1.2)
    ax3.set_xlabel("Time Step")
    ax3.set_ylabel("Margin (dB)")
    ax3.grid(True, linestyle="--", alpha=0.4)
    ax3.legend(fontsize=8, loc="best")

    plt.tight_layout()

    png_path = os.path.join(out_dir, "allocation_result.png")
    pdf_path = os.path.join(out_dir, "allocation_result.pdf")
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(pdf_path, bbox_inches="tight")
    plt.close()

    return png_path, pdf_path


# =========================
# CLI
# =========================
def cmd_eval(args):
    ensure_dir(args.out_dir)

    ep_df, all_steps_df = evaluate_episodes(
        project_root=args.project_root,
        checkpoint=args.checkpoint,
        episodes=args.episodes,
        start_pos_id=args.start_pos_id,
        seed=args.seed,
        explore=args.explore,
    )

    ep_csv = os.path.join(args.out_dir, "episode_metrics.csv")
    steps_csv = os.path.join(args.out_dir, "all_steps.csv")
    ep_df.to_csv(ep_csv, index=False)
    all_steps_df.to_csv(steps_csv, index=False)

    summary_df = summarize_metrics(ep_df)
    save_summary_table(summary_df, args.out_dir)

    print(f"Saved episode metrics: {ep_csv}")
    print(f"Saved step records:    {steps_csv}")
    print(summary_df.to_string(index=False))


def cmd_rollout(args):
    ensure_dir(args.out_dir)

    # 先评估若干回合，选一个代表性episode
    ep_df, all_steps_df = evaluate_episodes(
        project_root=args.project_root,
        checkpoint=args.checkpoint,
        episodes=args.episodes,
        start_pos_id=args.start_pos_id,
        seed=args.seed,
        explore=args.explore,
    )

    rep_ep = choose_representative_episode(ep_df)
    rep_steps = all_steps_df[all_steps_df["episode"] == rep_ep].copy()

    rep_csv = os.path.join(args.out_dir, "representative_episode.csv")
    rep_steps.to_csv(rep_csv, index=False)

    traj_png, traj_pdf = plot_trajectory(rep_steps, args.out_dir)
    alloc_png, alloc_pdf = plot_allocation(rep_steps, args.out_dir)

    rep_summary = ep_df[ep_df["episode"] == rep_ep].iloc[0].to_dict()
    with open(os.path.join(args.out_dir, "episode_summary.json"), "w", encoding="utf-8") as f:
        json.dump(rep_summary, f, indent=2, ensure_ascii=False)

    print(f"Representative episode: {rep_ep}")
    print(f"Saved representative CSV: {rep_csv}")
    print(f"Saved trajectory plot:    {traj_png}")
    print(f"Saved allocation plot:    {alloc_png}")


def cmd_curve(args):
    ensure_dir(args.out_dir)
    png_path, pdf_path = plot_training_curve(args.progress_csv, args.out_dir)
    print(f"Saved training curve: {png_path}")
    print(f"Saved training curve: {pdf_path}")


def build_parser():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="cmd", required=True)

    # eval
    p_eval = subparsers.add_parser("eval")
    p_eval.add_argument("--project_root", type=str, default=r"runs_rllib\mappo_nrs_exp\checkpoint_000100")
    p_eval.add_argument("--checkpoint", type=str, default="runs_rllib/mappo_ctde_nrs_20260308_154405/PPO_NRS_MAPPO_CTDE_966ff_00000_0_2026-03-08_15-44-07/checkpoint_000080")
    p_eval.add_argument("--episodes", type=int, default=50)
    p_eval.add_argument("--start_pos_id", type=int, default=0, help="0/1/2固定; -1表示随机")
    p_eval.add_argument("--seed", type=int, default=0)
    p_eval.add_argument("--explore", action="store_true")
    p_eval.add_argument("--out_dir", type=str, default="paper_outputs")
    p_eval.set_defaults(func=cmd_eval)

    # rollout
    p_roll = subparsers.add_parser("rollout")
    p_roll.add_argument("--project_root", type=str, default=r"runs_rllib\mappo_nrs_exp\checkpoint_000100")
    p_roll.add_argument("--checkpoint", type=str,  default="runs_rllib/mappo_ctde_nrs_20260308_154405/PPO_NRS_MAPPO_CTDE_966ff_00000_0_2026-03-08_15-44-07/checkpoint_000080")
    p_roll.add_argument("--episodes", type=int, default=20, help="先评估多少回合用于选代表性episode")
    p_roll.add_argument("--start_pos_id", type=int, default=0, help="0/1/2固定; -1表示随机")
    p_roll.add_argument("--seed", type=int, default=0)
    p_roll.add_argument("--explore", action="store_true")
    p_roll.add_argument("--out_dir", type=str, default="paper_outputs")
    p_roll.set_defaults(func=cmd_rollout)

    # curve
    p_curve = subparsers.add_parser("curve")
    p_curve.add_argument("--progress_csv", type=str,   default="runs_rllib/mappo_ctde_nrs_20260308_154405/PPO_NRS_MAPPO_CTDE_966ff_00000_0_2026-03-08_15-44-07/progress.csv")
    p_curve.add_argument("--out_dir", type=str, default="paper_outputs")
    p_curve.set_defaults(func=cmd_curve)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()