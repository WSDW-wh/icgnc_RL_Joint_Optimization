# train_mappo_ctde_rllib.py
import os
import argparse
from datetime import datetime

import ray
from ray import tune
from ray.rllib.algorithms.ppo import PPOConfig
from ray.rllib.models import ModelCatalog
from ray.tune.registry import register_env

from envs.nrs_mappo_env import NRSJammingMAPPOEnv
from models.mappo_cc_torch_model import MAPPOCentralizedCritic


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start_pos_id", type=int, default=0, help="0/1/2 fixed; -1 random among 3")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--total_timesteps", type=int, default=1000_000)
    ap.add_argument("--out_dir", type=str, default="runs_rllib")
    ap.add_argument("--cpu", type=int, default=4)
    ap.add_argument("--checkpoint_freq", type=int, default=10)
    args = ap.parse_args()

    start_pos_id = None if args.start_pos_id < 0 else int(args.start_pos_id)

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    exp_name = f"mappo_ctde_nrs_{run_id}"
    os.makedirs(args.out_dir, exist_ok=True)

    ray.init(num_cpus=args.cpu, ignore_reinit_error=True, include_dashboard=False)

    register_env("NRS_MAPPO_CTDE", lambda cfg: NRSJammingMAPPOEnv(cfg))
    ModelCatalog.register_custom_model("mappo_cc", MAPPOCentralizedCritic)

    env_config = {
        "seed": args.seed,
        "start_pos_id": start_pos_id,
        "include_teammate_rel": True,
    }

    # temp env for spaces
    tmp_env = NRSJammingMAPPOEnv(env_config)
    obs_space_j = tmp_env.observation_space("jammer")
    act_space_j = tmp_env.action_space("jammer")
    obs_space_f = tmp_env.observation_space("fighter")
    act_space_f = tmp_env.action_space("fighter")

    policies = {
        "jammer_policy": (None, obs_space_j, act_space_j, {}),
        "fighter_policy": (None, obs_space_f, act_space_f, {}),
    }

    def policy_mapping_fn(agent_id, *a, **k):
        return "jammer_policy" if agent_id == "jammer" else "fighter_policy"

    config = (
        PPOConfig()
        .environment(env="NRS_MAPPO_CTDE", env_config=env_config)
        .multi_agent(policies=policies, policy_mapping_fn=policy_mapping_fn)
        .training(
            lr=3e-4,
            gamma=0.995,
            lambda_=0.95,
            clip_param=0.2,
            vf_clip_param=10.0,
            entropy_coeff=0.05,
            train_batch_size=10000,
            sgd_minibatch_size=512,
            num_sgd_iter=10,
            model={
                "custom_model": "mappo_cc",
                "fcnet_hiddens": [128, 128],
                "fcnet_activation": "tanh",
            },
        )
        .rollouts(
            num_rollout_workers=0,
            rollout_fragment_length=1000,
        )
        .resources(num_gpus=0)
        .framework("torch")
        .debugging(log_level="INFO")
    ).to_dict()

    results = tune.run(
        "PPO",
        name=exp_name,
        local_dir=args.out_dir,
        stop={"timesteps_total": args.total_timesteps},
        config=config,
        checkpoint_freq=int(args.checkpoint_freq),
        checkpoint_at_end=True,
        keep_checkpoints_num=3,
        metric="episode_reward_mean",
        mode="max",
        verbose=1,
    )

    best_trial = results.get_best_trial(metric="episode_reward_mean", mode="max", scope="all")
    best_ckpt = results.get_best_checkpoint(best_trial, metric="episode_reward_mean", mode="max")
    print("\nDone.")
    print("Best trial:", best_trial)
    print("Best checkpoint:", best_ckpt)

    ray.shutdown()


if __name__ == "__main__":
    main()